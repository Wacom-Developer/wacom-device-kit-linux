GtkWidget *
do_drawingarea (GtkWidget *do_widget);

GtkWidget *
do_paint       (GtkWidget *do_widget);

GtkWidget *
do_event_axes  (GtkWidget *do_widget);
