# example-kernel for wacom devices
Example code that uses OSS APIs to read from Wacom devices.

This guide was created to illustrate Linux kernel Input APIs relavent to Wacom devices.

Commands to build and run the programs can be found at the top of the files in the comment block 
